package com.example.laba6_franikowski.model

data class Faculty(var id: Int?, var title: String)